var searchData=
[
  ['tarefa_0',['Tarefa',['../classTarefa.html',1,'']]],
  ['texto_1',['Texto',['../classTexto.html',1,'']]]
];
