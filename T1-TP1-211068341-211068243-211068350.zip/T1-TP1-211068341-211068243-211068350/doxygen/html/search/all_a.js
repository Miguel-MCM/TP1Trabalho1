var searchData=
[
  ['valor_0',['valor',['../classDominio.html#adf6b3cc90ca5abce6cd462cdb313220e',1,'Dominio']]]
];
