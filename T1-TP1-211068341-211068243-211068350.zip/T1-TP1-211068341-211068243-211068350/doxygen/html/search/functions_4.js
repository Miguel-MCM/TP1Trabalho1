var searchData=
[
  ['setcodigo_0',['setCodigo',['../classProjeto.html#a7474ab46180b997142a9497104dee87f',1,'Projeto']]],
  ['setdescricao_1',['setDescricao',['../classProjeto.html#aa5b9d3c4894850e326b3c3e28a9670d7',1,'Projeto']]],
  ['setnome_2',['setNome',['../classProjeto.html#ac33a12a558a5ced45b614aaedbb38c26',1,'Projeto']]],
  ['setvalor_3',['setValor',['../classDominio.html#a8d0e7995d6252d5e3b15596ca8610f24',1,'Dominio']]]
];
